const cities = {
  solaria: {
    name: "Solaria City",
    description: "Cidade tecnológica no deserto.\nPokémon comuns: Sandshrew, Trapinch, Growlithe."
  },
  kaalu: {
    name: "Ka’alu Town",
    description: "Centro cultural com ruínas antigas.\nPokémon comuns: Pidgey, Oddish, Buneary."
  },
  sapphire: {
    name: "Sapphire Bay",
    description: "Vila pesqueira costeira.\nPokémon comuns: Wingull, Magikarp, Krabby."
  },
  lunaro: {
    name: "Lunaro Village",
    description: "Cidade espiritual com templos antigos.\nPokémon comuns: Gastly, Ralts, Sableye."
  },
  verdancia: {
    name: "Verdancia Town",
    description: "Florestas agrícolas.\nPokémon comuns: Caterpie, Combee, Petilil."
  },
  drakestone: {
    name: "Drakestone City",
    description: "Cavernas montanhosas lendárias.\nPokémon comuns: Dratini, Onix, Mawile."
  },
  aurora: {
    name: "Aurora Port",
    description: "Porto comercial com influências estrangeiras.\nPokémon comuns: Tentacool, Lapras, Delibird."
  },
  sylvara: {
    name: "Sylvara Village",
    description: "Vila em harmonia com a floresta.\nPokémon comuns: Deerling, Sewaddle, Cutiefly."
  }
};

const tooltip = document.getElementById("tooltip");
const cityElements = document.querySelectorAll(".city");

cityElements.forEach(city => {
  city.addEventListener("mouseenter", (e) => {
    const cityData = cities[city.dataset.city];
    tooltip.innerHTML = `<strong>${cityData.name}</strong><br>${cityData.description.replace(/\n/g, "<br>")}`;
    tooltip.style.display = "block";
  });

  city.addEventListener("mousemove", (e) => {
    tooltip.style.left = e.pageX + 15 + "px";
    tooltip.style.top = e.pageY + 15 + "px";
  });

  city.addEventListener("mouseleave", () => {
    tooltip.style.display = "none";
  });
});
